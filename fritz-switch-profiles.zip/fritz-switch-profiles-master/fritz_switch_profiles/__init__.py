"""fritz_switch_profiles"""
import logging

from .fritz_switch_profiles import FritzProfileSwitch  # noqa

logging.getLogger(__name__).addHandler(logging.NullHandler())

__version__ = "1.1.3"
