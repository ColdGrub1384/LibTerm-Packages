# Changelog

<!--next-version-placeholder-->

## v1.1.3 (2020-12-07)
### Fix
* Trigger release ([`b4e858e`](https://github.com/eifinger/fritz-switch-profiles/commit/b4e858e919c00be0439090dc2dc6b311d5e16278))
