# Hulk DoS tool - Go version

```
# Build
sudo docker build -t hulk .

# Run
sudo docker run -it hulk -site localhost
```
