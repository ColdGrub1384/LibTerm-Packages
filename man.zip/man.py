#!/usr/bin/python3

from sys import argv

cmd = {
    "libterm":
    "Libetrm Version 5.2.2 (1)",
    "version":
    "man version 0.5.0",
    "man": 
    """
NAME
    man
USAGE
    man <name_of_command>
DESCRIPTION
    man is a command that allows you to see the usage and
    definition of a command. You can specify which
    command you wish to see by using
    man <name_of_command>.
    """,
    
    "ls":
    """
NAME
    ls
USAGE
    ls <-ABCFGHLOPRSTUW@abcdefghiklmnopqrstuwx1%> <optional_path_to_dir>
DESCRIPTION
    ls is a command that allows you to see the files
    or directories in the current directory or other files.
    """,
    "cd":
    """
NAME
    cd
USAGE
    cd <path_to_dir>
DESCRIPTION
    cd is a command that allows you to go to a
    specific directory to change your current
    working directory.
    """,
    "pwd":
    """
NAME
    pwd
USAGE
    pwd<-L / -P>
DESCRIPTION
    pwd is a command that allows you to view
    your current working directory.
    -L will display the logical working directory.
    -P will display the physical working directory.
    """
}

if len(argv) != 2:
    print("What manual page do you want?")
    exit(0)

try:
    print(cmd[argv[1]])
except:
    print("No manual entry for " + argv[1])
    exit(1)