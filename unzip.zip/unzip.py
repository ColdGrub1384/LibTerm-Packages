import sys
import zipfile
import os

if os.path.isfile(sys.argv[1):
 with zipfile.ZipFile(sys.argv[1], 'r') as zip_ref:
     zip_ref.extractall(sys.argv[1][:-4])
else:
 print("Usage: unzip <zip_file>")
