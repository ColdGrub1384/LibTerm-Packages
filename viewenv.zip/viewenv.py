﻿import os
print("\033[33m")
for key, value in os.environ.items():
	print(key, "=", value)
	print()
print("\033[0m")