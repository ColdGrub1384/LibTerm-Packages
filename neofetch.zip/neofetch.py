import os
import getpass
import platform

uname = os.uname()

apple = """                    'c.	
                 ,xNMM.	
               .OMMMMo	
               OMMM0,
     .;loddo:' loolloddol;.	
   cKMMMMMMMMMMNWMMMMMMMMMM0:
 .KMMMMMMMMMMMMMMMMMMMMMMMWd.
 XMMMMMMMMMMMMMMMMMMMMMMMX.	
;MMMMMMMMMMMMMMMMMMMMMMMM:
:MMMMMMMMMMMMMMMMMMMMMMMM:
.MMMMMMMMMMMMMMMMMMMMMMMMX.
 kMMMMMMMMMMMMMMMMMMMMMMMMWd.
 .XMMMMMMMMMMMMMMMMMMMMMMMMMMk
  .XMMMMMMMMMMMMMMMMMMMMMMMMk.
    kMMMMMMMMMMMMMMMMMMMMMMd	
     ;KMMMMMMMWXXWMMMMMMMk.
       .cooc,.    .,coo:."""

lengths = []
split = apple.split("\n")
for line in split:
	lengths.append(len(line))
infoat = max(lengths) + 3

lines = []
for line in split:
	lines.append(line + (" " * (infoat - len(line))))


user = getpass.getuser()
hostname = uname.nodename
os = "iOS " + platform.mac_ver()[0]
host = platform.machine().split(",")[0].replace("iPad", "iPad ").replace("iPhone", "iPhone")
kernel = platform.release()
terminal = "LibTerm"


info = [
	user + "@" + hostname,
	"-" * len(user + "@" + hostname),
	"OS: " + os,
	"   Host: " + host,
	"Kernel: " + kernel,
	"   Terminal: " + terminal
]
linect = lines.__sizeof__()
i = 0
for line in info:
	if i >= linect:
		lines[i] = " " * infoat + line
	else:
		lines[i] = lines[i] + line
	i += 1

for line in lines:
	print(line)
