import random

min = 0
max = 10

print("Your random number is: " + str(random.randint(min, max)))
