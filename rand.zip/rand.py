import random

min = int(input("Enter the minimum number: "))
max = int(input("Enter the maximum number: "))

print("Your random number is: " + str(random.randint(min, max)))
