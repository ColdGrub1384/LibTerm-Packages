# FreeBSD style sha256 command
# See: https://www.freebsd.org/cgi/man.cgi?query=md5&sektion=1&manpath=FreeBSD+4.8-stable
# Similar to the LibTerm built-in `md5` command

# Expected flags:
# usage: program_name [-pqrtx] [-s string] [files ...]

import hashlib, argparse, sys
from typing import List, Optional

READ_BUFFER_SIZE = 4096

def main(hash_func_name: str, hashlib_name: str, progname: str=None):
    if progname == None:
        progname = hash_func_name.lower()
    parser = argparse.ArgumentParser(progname)

    # parser.add_argument('-p', action='store_true', help='Echo stdin to stdout and append the checksum to stdout.')
    parser.add_argument('-q', action='store_true', help='Quiet mode -- only the checksum is printed out. Overrides the -r option.')
    parser.add_argument('-r', action='store_true', help='Reverses the format of the output. This helps with visual diffs. Does nothing when combined with the -ptx options.')

    parser.add_argument('-s', dest='string', type=str, help='Print a checksum of the given string.')
    parser.add_argument('files', metavar='FILE', type=str, nargs='*')

    args = parser.parse_args()

    def output_print(obj: Optional[str], hexdigest: str):
        if args.q or obj == None:
            print(hexdigest)
        elif args.r:
            print('{} {}'.format(hexdigest, obj))
        else:
            print('{} ({}) = {}'.format(hash_func_name, obj, hexdigest))

    def hash_string(s: str):
        hobj = hashlib.new(hashlib_name)
        hobj.update(s.encode())
        output_print('"' + s + '"', hobj.hexdigest())
    
    def print_os_error(error: OSError):
        if error.filename != None:
            print('{}: {}: {}'.format(progname, error.filename, error.strerror), file=sys.stderr)
        else:
            print('{}: {}'.format(progname, error.strerror), file=sys.stderr)

    def hash_generic_file(file):
        hobj = hashlib.new(hashlib_name)
        while True:
            data = file.read1(READ_BUFFER_SIZE)
            if data == b'':
                break
            hobj.update(data)
        return hobj.hexdigest()
    
    def hash_file(filename: str):
        try:
            with open(filename, 'rb') as file:
                hexdigest = hash_generic_file(file)
        except OSError as error:
            print_os_error(error)
        else:
            output_print(filename, hexdigest)
    
    def hash_stdin():
        try:
            hexdigest = hash_generic_file(sys.stdin.buffer)
        except OSError as error:
            print_os_error(error)
        else:
            output_print(None, hexdigest)
    
    if args.string != None:
        hash_string(args.string)
    files: List[str] = args.files
    if files:
        for filename in files:
            hash_file(filename)
    elif args.string == None:
        hash_stdin()

if __name__ == "__main__":
    main('SHA256', 'sha256')
