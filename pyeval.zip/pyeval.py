﻿import sys
cmd = " ".join(sys.argv[1:])
print(eval(cmd))